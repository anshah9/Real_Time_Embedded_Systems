#include <device.h>
#include <zephyr/types.h>
#include <stdlib.h>
#include <kernel.h>
#include <string.h>
#include <board.h>
#include <sensor.h>
#include <gpio.h>
#include <errno.h>
#include <misc/byteorder.h>
#include <misc/__assert.h>

#include "hcsr04.h"
//|GPIO_PUD_PULL_DOWN
#define EDGE (GPIO_INT_EDGE | GPIO_INT_ACTIVE_HIGH) // High edge confuguration macros

#define EDGE_1 (GPIO_INT_EDGE | GPIO_INT_ACTIVE_LOW) // High edge confuguration macros

static struct gpio_callback callb;	// callback object 


struct device *dev1;				// device pointer to set gpios
struct device *dev2;
struct device *dev3;
struct device *dev4;
struct device *dev5;
struct device *dev6;

int check = 0;
int value;

u64_t start=0,stop=0, diff=0;



void handler(struct device *dev6, struct gpio_callback *callb, u32_t pin){	// Callback interrupt handler
	int ret;
	
	gpio_pin_read(dev6, 3 ,&value);
	//printk("Inside call back");
	printk("value = %d\n", value);
	
	if(value == 1){
		stop = _tsc_read();
		ret = gpio_pin_configure(dev6,3,GPIO_DIR_IN | GPIO_INT | EDGE_1);	

		// if (ret != 0) {
		// 	printk("Low GPIO config error %d!!\n", ret);
		// }
	}

	else
	{
	ret = gpio_pin_configure(dev6,3,GPIO_DIR_IN | GPIO_INT | EDGE);
	// if (ret != 0) {
	// 	printk("High GPIO config error %d!!\n", ret);
	// }
	  start = _tsc_read();	

	  diff = start - stop;

	  gpio_pin_disable_callback(dev6,3);	// disable interrupt handler


	}
	printk("The difference is = %llu \n", diff);

	// stop_time=_tsc_read();
	// diff=stop_time-start_time;
	// if(array_flag=='a'){
	// 	// printk("\n Latency W/O background task %lld\n",diff);
	// 	int_wo_back[count]=diff;			// calculates latency and stores it in the buffer for without any background task
	// }
	// else if(array_flag=='b'){
	// 	// printk("\n latency with background tasks %lld\n",diff);
	// 	int_back[count]=diff;				// calculates latency and stores it in the buffer for with background task
	// }
	// count+=1;

}


static int hcsr_sample_fetch(struct device *dev, enum sensor_channel chan)
{
	struct hcsr_data *drv_data = dev->driver_data;
	int flag;
	
	printk("In the sample_fetch....\n");

	

	flag=gpio_pin_write(dev3,4,1); 
	if(flag<0)
		printk("Error in gpio_pin_write 3");

	// k_busy_wait(15);
	k_sleep(500);

	flag=gpio_pin_write(dev3,4,0); 
	if(flag<0)
		printk("Error in gpio_pin_write 3");


	printk("gpio_pin_write in 3\n");

	//gpio_pin_disable_callback(dev6,3);

	
	// u16_t val;

	// __ASSERT_NO_MSG(chan == SENSOR_CHAN_ALL || chan == SENSOR_CHAN_TEMP);

	// if (tmp007_reg_read(drv_data, TMP007_REG_TOBJ, &val) < 0) {
	// 	return -EIO;
	// }

	// if (val & hcsr_data_INVALID_BIT) {
	// 	return -EIO;
	// }

	// drv_data->sample = arithmetic_shift_right((s16_t)val, 2);

	return 0;
}

static int hcsr_channel_get(struct device *dev,
			       enum sensor_channel chan,
			       struct sensor_value *val)
{
	struct hcsr_data *drv_data = dev->driver_data;

	printk("In the channel_get....\n");


	// s32_t uval;

	// if (chan != SENSOR_CHAN_TEMP) {
	// 	return -ENOTSUP;
	// }

	// uval = (s32_t)drv_data->sample * TMP007_TEMP_SCALE;
	// val->val1 = uval / 1000000;
	// val->val2 = uval % 1000000;

	return 0;
}

static const struct sensor_driver_api hcsr_driver_api = {
// #ifdef CONFIG_TMP007_TRIGGER
// 	.attr_set = tmp007_attr_set,
// 	.trigger_set = tmp007_trigger_set,
// #endif
	.sample_fetch = hcsr_sample_fetch,
	.channel_get = hcsr_channel_get,
};



static int hcsr_init(struct device *dev){

	printk("In the init....0\n");
	struct hcsr_data *drv_data = dev->driver_data;

	// drv_data->i2c = device_get_binding(CONFIG_HCSR_GPIO_MASTER_DEV_NAME);
	// if (drv_data->i2c == NULL) {
	// 	printk("Failed to get pointer to %s device!",
	// 		    CONFIG_HCSR_GPIO_MASTER_DEV_NAME);
	// 	return -EINVAL;
	// }

	// printk("In the init....1\n");

// #ifdef CONFIG_HCSR_TRIGGER
// 	if (hcsr_init_interrupt(dev) < 0) {
// 		SYS_LOG_DBG("Failed to initialize interrupt!");
// 		return -EIO;
// 	}
// #endif

	int flag;

	printk("Setting gpios\n");

	dev1 = device_get_binding("EXP0");
	if(dev1==NULL)
		printk("Returning null 1");
	flag=gpio_pin_configure(dev1,12,GPIO_DIR_OUT);
	if(flag<0)
		printk("Error in gpio_pin_configure 1");
	flag=gpio_pin_write(dev1,12,0);
	if(flag<0)
		printk("Error in gpio_pin_write 1");



	dev2 = device_get_binding("EXP1");
	if(dev2==NULL)
		printk("Returning null 2");
	flag=gpio_pin_configure(dev2,13,GPIO_DIR_OUT);
	if(flag<0)
		printk("Error in gpio_pin_configure 2");
	flag=gpio_pin_write(dev2,13,0);
	if(flag<0)
		printk("Error in gpio_pin_write 2");


		
	dev3 = device_get_binding("GPIO_0");
	if(dev3==NULL)
		printk("Returning null 3");
	flag=gpio_pin_configure(dev3,4, GPIO_DIR_OUT);
	if(flag<0)
		printk("Error in gpio_pin_configure 3");
	flag=gpio_pin_write(dev3,4,0); 
	if(flag<0)
		printk("Error in gpio_pin_write 3");


	dev4 = device_get_binding("EXP1");
	if(dev4==NULL)
		printk("Returning null 4");
	flag=gpio_pin_configure(dev4,0,GPIO_DIR_OUT);
	if(flag<0)
		printk("Error in gpio_pin_configure 4");
	flag=gpio_pin_write(dev4,0,1);
	if(flag<0)
		printk("Error in gpio_pin_write 4");



	dev5 = device_get_binding("EXP1");
	if(dev5==NULL)
		printk("Returning null 5");
	flag=gpio_pin_configure(dev5,1,GPIO_DIR_OUT);
	if(flag<0)
		printk("Error in gpio_pin_configure 5");
	flag=gpio_pin_write(dev5,1,0);
	if(flag<0)
		printk("Error in gpio_pin_write 5");

		
	dev6 = device_get_binding("GPIO_0");
	if(dev6==NULL)
		printk("Returning null 6");
	flag=gpio_pin_configure(dev6,3,GPIO_DIR_IN | GPIO_INT | EDGE);
	if(flag<0)
		printk("Error in gpio_pin_configure 6");
	if(flag<0)
		printk("Error in gpio_pin_write 6");

	printk("gpio_set end\n");


	gpio_init_callback(&callb,handler, BIT(3));// intializing callback on the IO0
	gpio_add_callback(dev6, &callb);	//binding call back with device pointer
	gpio_pin_enable_callback(dev6,3);	// enabling interrupt handler
		
	dev->driver_api = &hcsr_driver_api;

	printk("In the init....2\n");

	return 0;

}

// DEVICE_DECLARE(HCSR0);

struct hcsr_data hcsr_driver_0, hcsr_driver_1;

DEVICE_INIT(HCSR0, CONFIG_HCSR_NAME_0, hcsr_init,
		    &hcsr_driver_0, NULL,
		    POST_KERNEL, CONFIG_SENSOR_INIT_PRIORITY);

DEVICE_INIT(HCSR1, CONFIG_HCSR_NAME, hcsr_init,
		    &hcsr_driver_1, NULL,
		    POST_KERNEL, CONFIG_SENSOR_INIT_PRIORITY);