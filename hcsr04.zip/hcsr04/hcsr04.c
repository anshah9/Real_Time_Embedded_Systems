#include <zephyr/types.h>
#include <stdlib.h>
#include <kernel.h>
#include <string.h>
#include <board.h>
#include <sensor.h>
#include <gpio.h>
#include <errno.h>

#include "hcsr04.h"


static int hcsr_sample_fetch(struct device *dev, enum sensor_channel chan)
{
	struct hcsr_data *drv_data = dev->driver_data;
	// u16_t val;

	// __ASSERT_NO_MSG(chan == SENSOR_CHAN_ALL || chan == SENSOR_CHAN_TEMP);

	// if (tmp007_reg_read(drv_data, TMP007_REG_TOBJ, &val) < 0) {
	// 	return -EIO;
	// }

	// if (val & hcsr_data_INVALID_BIT) {
	// 	return -EIO;
	// }

	// drv_data->sample = arithmetic_shift_right((s16_t)val, 2);

	return 0;
}

static int hcsr_channel_get(struct device *dev,
			       enum sensor_channel chan,
			       struct sensor_value *val)
{
	struct hcsr_data *drv_data = dev->driver_data;
	// s32_t uval;

	// if (chan != SENSOR_CHAN_TEMP) {
	// 	return -ENOTSUP;
	// }

	// uval = (s32_t)drv_data->sample * TMP007_TEMP_SCALE;
	// val->val1 = uval / 1000000;
	// val->val2 = uval % 1000000;

	return 0;
}

static const struct sensor_driver_api hcsr_driver_api = {
// #ifdef CONFIG_TMP007_TRIGGER
// 	.attr_set = tmp007_attr_set,
// 	.trigger_set = tmp007_trigger_set,
// #endif
// 	.sample_fetch = hcsr_sample_fetch,
// 	.channel_get = hcsr_channel_get,
};



static int hcsr_init(struct device *dev){

	struct hcsr_data *drv_data = dev->driver_data;

	drv_data->i2c = device_get_binding(CONFIG_HCSR_GPIO_MASTER_DEV_NAME);
	if (drv_data->i2c == NULL) {
		SYS_LOG_DBG("Failed to get pointer to %s device!",
			    CONFIG_HCSR_GPIO_MASTER_DEV_NAME);
		return -EINVAL;
	}

#ifdef CONFIG_HCSR_TRIGGER
	if (hcsr_init_interrupt(dev) < 0) {
		SYS_LOG_DBG("Failed to initialize interrupt!");
		return -EIO;
	}
#endif

	dev->driver_api = &hcsr_driver_api;

	return 0;

}

//DEVICE_DECLARE(hcsr_0);

static struct hcsr_data hcsr_driver;

DEVICE_INIT(HCSR0, hc-sr04, hcsr_init,
		    &hcsr_driver, NULL,
		    POST_KERNEL, CONFIG_SENSOR_INIT_PRIORITY);

DEVICE_INIT(HCSR1, hc-sr04, hcsr_init,
		    &hcsr_driver, NULL,
		    POST_KERNEL, CONFIG_SENSOR_INIT_PRIORITY);