#include <device.h>
#include <gpio.h>
#include <misc/util.h>
#include <kernel.h>
#include <sensor.h>

#include "hcsr04.h"

extern struct hcsr_data hcsr_driver;


int hcsr_init_interrupt(struct device *dev){
	
	struct hcsr_data *drv_data = dev->driver_data;

// 	if (tmp007_reg_update(drv_data, TMP007_REG_CONFIG,
// 			      TMP007_ALERT_EN_BIT, TMP007_ALERT_EN_BIT) < 0) {
// 		SYS_LOG_DBG("Failed to enable interrupt pin!");
// 		return -EIO;
// 	}

// 	/* setup gpio interrupt */
// 	drv_data->gpio = device_get_binding(CONFIG_TMP007_GPIO_DEV_NAME);
// 	if (drv_data->gpio == NULL) {
// 		SYS_LOG_DBG("Failed to get pointer to %s device!",
// 		    CONFIG_TMP007_GPIO_DEV_NAME);
// 		return -EINVAL;
// 	}

// 	gpio_pin_configure(drv_data->gpio, CONFIG_TMP007_GPIO_PIN_NUM,
// 			   GPIO_DIR_IN | GPIO_INT | GPIO_INT_LEVEL |
// 			   GPIO_INT_ACTIVE_HIGH | GPIO_INT_DEBOUNCE);

// 	gpio_init_callback(&drv_data->gpio_cb,
// 			   tmp007_gpio_callback,
// 			   BIT(CONFIG_TMP007_GPIO_PIN_NUM));

// 	if (gpio_add_callback(drv_data->gpio, &drv_data->gpio_cb) < 0) {
// 		SYS_LOG_DBG("Failed to set gpio callback!");
// 		return -EIO;
// 	}

// #if defined(CONFIG_TMP007_TRIGGER_OWN_THREAD)
// 	k_sem_init(&drv_data->gpio_sem, 0, UINT_MAX);

// 	k_thread_create(&drv_data->thread, drv_data->thread_stack,
// 			CONFIG_TMP007_THREAD_STACK_SIZE,
// 			(k_thread_entry_t)tmp007_thread, POINTER_TO_INT(dev),
// 			0, NULL, K_PRIO_COOP(CONFIG_TMP007_THREAD_PRIORITY),
// 			0, 0);
// #elif defined(CONFIG_TMP007_TRIGGER_GLOBAL_THREAD)
// 	drv_data->work.handler = tmp007_work_cb;
// 	drv_data->dev = dev;
// #endif

	return 0;
}
