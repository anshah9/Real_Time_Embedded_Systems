#include <device.h>
#include <gpio.h>
#include <misc/util.h>



struct hcsr_data {
	struct device *i2c;
	s16_t sample;

// #ifdef CONFIG_HCSR_TRIGGER
// 	struct device *gpio;
// 	struct gpio_callback gpio_cb;

// 	sensor_trigger_handler_t drdy_handler;
// 	struct sensor_trigger drdy_trigger;

// 	sensor_trigger_handler_t th_handler;
// 	struct sensor_trigger th_trigger;

// // #if defined(CONFIG_TMP007_TRIGGER_OWN_THREAD)
// // 	K_THREAD_STACK_MEMBER(thread_stack, CONFIG_TMP007_THREAD_STACK_SIZE);
// // 	struct k_sem gpio_sem;
// // 	struct k_thread thread;
// // #elif defined(CONFIG_TMP007_TRIGGER_GLOBAL_THREAD)
// // 	struct k_work work;
// // 	struct device *dev;
// // #endif

// #endif /* CONFIG_HCSR_TRIGGER */
};

